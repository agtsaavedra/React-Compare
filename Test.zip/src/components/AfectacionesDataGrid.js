// src/components/AfectacionesDataGrid.js
import React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Box } from '@mui/material';

const getComparisonColumns = (afectaciones1, afectaciones2, tableType) => {
  const keys = Object.keys(afectaciones1[0] || {}).concat(Object.keys(afectaciones2[0] || {}));
  const uniqueKeys = [...new Set(keys)];
  
  return uniqueKeys.map((key) => ({
    field: key,
    headerName: key.replace(/_/g, ' ').toUpperCase(),
    width: key.length * 15,
    headerClassName: 'header-cell',
    cellClassName: (params) => {
      const rowIndex = params.id - 1;
      const value1 = afectaciones1[rowIndex] ? afectaciones1[rowIndex][key] : null;
      const value2 = afectaciones2[rowIndex] ? afectaciones2[rowIndex][key] : null;
      
      if (value1 !== value2) {
        return tableType === 'table1' ? 'cell-different-red' : 'cell-different-green';
      }
      return '';
    },
  }));
};

const getRowsWithIds = (afectaciones) =>
  afectaciones.map((afectacion, index) => ({
    id: index + 1,
    ...afectacion,
  }));

const AfectacionesDataGrid = ({ afectaciones1, afectaciones2, tableType, filterText }) => {
  const columns = getComparisonColumns(afectaciones1, afectaciones2, tableType);

  // Filtrar filas por Legajo y Función
  const filteredRows = getRowsWithIds(afectaciones1).filter(
    (row) =>
      row.Legajo.toString().includes(filterText) ||
      row.Funcion_descripcion.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <Box sx={{ height: '100%', width: '100%' }}>
      <DataGrid
        rows={filteredRows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
        checkboxSelection
        getCellClassName={(params) => params.cellClassName}
      />
    </Box>
  );
};

export default AfectacionesDataGrid;